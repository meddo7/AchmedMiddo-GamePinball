create database `daftar_siswa`;

use `daftar_siswa`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL primary key,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
);

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL primary key,
  `name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
);
