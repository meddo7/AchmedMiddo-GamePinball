<?php session_start(); ?>

<?php
if (!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
include_once("connection.php");

if (isset($_POST['update'])) {
	$id = $_POST['id'];

	$name = $_POST['name'];
	$address = $_POST['address'];
	$religion = $_POST['religion'];
	$class = $_POST['class'];
	$birthdate = $_POST['birthdate'];
	$gender = $_POST['gender'];

	if (empty($name) || empty($address) || empty($religion) || empty($class) || empty($birthdate) || empty($gender)) {

		if (empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if (empty($address)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}

		if (empty($religion)) {
			echo "<font color='red'>religion field is empty.</font><br/>";
		}
		if (empty($class)) {
			echo "<font color='red'>class field is empty.</font><br/>";
		}
		if (empty($birthdate)) {
			echo "<font color='red'>birthdate field is empty.</font><br/>";
		}
		if (empty($gender)) {
			echo "<font color='red'>gender field is empty.</font><br/>";
		}
	} else {
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE siswa SET name='$name', address='$address', religion='$religion', class='$class', birthdate='$birthdate', gender='$gender'  WHERE id=$id");

		//redirectig to the display page. In our case, it is view.php
		header("Location: view.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM siswa WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
	$name = $res['name'];
	$address = $res['address'];
	$religion = $res['religion'];
	$class = $res['class'];
	$birthdate = $res['birthdate'];
	$gender = $res['gender'];
}
?>
<html>

<head>
	<title>Edit Data</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">

</head>

<body>
	<a href="index.php">Home</a> | <a href="view.php">View Products</a> | <a href="logout.php">Logout</a>
	<br /><br />

	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $name; ?>"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="<?php echo $address; ?>"></td>
			</tr>
			<tr>
				<td>Religion</td>
				<td><input type="text" name="religion" value="<?php echo $religion; ?>"></td>
			</tr>
			<tr>
				<td>Class</td>
				<td><input type="text" name="class" value="<?php echo $class; ?>"></td>
			</tr>
			<tr>
				<td>Birthdate</td>
				<td><input type="date" name="birthdate" required<?php echo $birthdate; ?>></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><select name="gender" required<?php echo $gender; ?>>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
						<option value="Trans">Trans</option>
						<option value="Non-binary">Non-Binary</option>
						<option value="Null">Prefer Not To Say</option>
					</select>
				</td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</body>

</html>